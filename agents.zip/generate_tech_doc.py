#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成《厚粲杯 AIGC 绿色消费实验 Agent 技术文档》Word 文档。"""

import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

import generate_agents as GA  # noqa: E402
from docx import Document  # noqa: E402
from docx.shared import Pt, RGBColor  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402

OUT = os.path.join(BASE, '厚粲杯_AIGC绿色消费实验Agent技术文档.docx')

# 与 generate_agents.py 中 JS 保持一致的组别语气收尾（自然融入核心操纵元素）
CLOSING = {
    'collaboration': {
        '优点': '它（们）的这些优点，正是我们共同选择环保产品、为环保做出贡献的理由。',
        '好处': '这也让我们在为环保做出贡献的同时，收获更多。',
        '缺点': '虽然有一些不足，但为环保计，它仍值得我们一起选择。',
        '用途': '日常使用中，我们也能一起为环保尽一份力。',
        '价格': '多付一点，是我们一起为环保尽的心意。',
        '安全': '健康又环保，值得我们一起选择。',
        '耐用': '健康又环保，值得我们一起选择。',
        '材质': '选择这样的环保材质，正是我们为环保做出的选择。',
        '规格': '日常使用中，我们也能一起为环保尽一份力。',
        '效果': '这些效果，正是我们共同选择环保产品的理由。',
        '性价比': '多付一点，是我们一起为环保尽的心意。',
        '口碑': '越来越多的人加入我们，一起选择环保产品。',
        '环保意义': '这正是我们一起为环保做出贡献的意义。',
        '降解': '选择可降解材质，正是我们一起为环保尽的一份力。',
        '购买渠道': '欢迎加入我们，一起选择环保款。',
        '适用人群': '无论哪类人群，都能一起为环保做出贡献。',
        '注意事项': '虽然有一些注意点，但为环保计，它仍值得我们一起选择。',
        '对比': '综合来看，加入我们一起选择环保款，就是为环保做出贡献。',
        '推荐': '加入我们，一起为环保做出贡献。',
        'eco': '这也正是我们共同守护环境的方式。',
    },
    'non_collaboration': {
        '优点': '这些优点，正是绿色消费的优选理由。',
        '好处': '这也是您为绿色消费尽的一份力。',
        '缺点': '虽然有一些不足，但为环保计，您仍可考虑它。',
        '用途': '日常使用中，您也能为绿色消费尽一份力。',
        '价格': '多付一点，是您为环保尽的心意。',
        '安全': '健康又环保，值得您选择。',
        '耐用': '健康又环保，值得您选择。',
        '材质': '选择这样的环保材质，是您为环保做出的选择。',
        '规格': '日常使用中，您也能为绿色消费尽一份力。',
        '效果': '这些效果，正是绿色消费的优选理由。',
        '性价比': '多付一点，是您为环保尽的心意。',
        '口碑': '越来越多的人选择绿色消费。',
        '环保意义': '这正是绿色消费的意义所在。',
        '降解': '选择可降解材质，是您为环保尽的一份力。',
        '购买渠道': '欢迎您选择环保款。',
        '适用人群': '无论哪类人群，都能为绿色消费尽一份力。',
        '注意事项': '虽然有一些注意点，但为环保计，您仍可考虑它。',
        '对比': '综合来看，请您选择绿色消费，环保款更值得考虑。',
        '推荐': '请您选择绿色消费，环保款值得考虑。',
        'eco': '这也正是您践行绿色消费的方式。',
    },
}

LABEL = {'优点': '优点', '好处': '好处', '缺点': '缺点', '用途': '用途',
         '价格': '价格', '安全': '安全性', '耐用': '耐用性'}


def set_font(run, name='微软雅黑', size=10.5, bold=False, color=None):
    run.font.name = name
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)
    run._element.rPr.rFonts.set(qn('w:eastAsia'), name)


def p(doc, text, size=10.5, bold=False, color=None, style=None):
    para = doc.add_paragraph(style=style)
    run = para.add_run(text)
    set_font(run, size=size, bold=bold, color=color)
    return para


def heading(doc, text, level=1):
    h = doc.add_heading('', level=level)
    run = h.add_run(text)
    set_font(run, size={1: 16, 2: 13, 3: 11.5}.get(level, 11), bold=True,
             color=(0x1F, 0x3D, 0x24))
    return h


def build_doc():
    doc = Document()

    title = doc.add_heading('', 0)
    run = title.add_run('厚粲杯 · AIGC 绿色消费实验 Agent 技术文档')
    set_font(run, size=18, bold=True, color=(0x1F, 0x3D, 0x24))
    p(doc, '第二届"厚粲杯"全国大学生心理与认知智能测评挑战赛 参赛项目', size=11, color=(0x55, 0x55, 0x55))

    # ========== 一、技术栈 ==========
    heading(doc, '一、技术栈', 1)
    p(doc, '本套实验 Agent 为纯前端实现，无后端依赖，可直接嵌入见数（Credamo）平台运行。', size=10.5)
    for k, v in [
        ('生成脚本', 'Python 3（generate_agents.py 生成 12 个 Agent，wrap_iframe.py / wrap_noscript.py 生成见数兼容版本）'),
        ('Agent 本体', 'HTML5 + CSS3 + 原生 JavaScript（ES5，无任何第三方库，离线可运行）'),
        ('见数兼容方案 1', 'agents_iframe：内层 HTML 整体 base64 编码，嵌入 iframe 的 data URI，隐藏 <script>/<style> 标签'),
        ('见数兼容方案 2', 'agents_noscript：零 <script> 标签，JS 经 base64 编码存入隐藏 <div>，由 <body onload> 用 new Function 解码执行'),
        ('数据回传', 'window.postMessage（向宿主页面报告 session_init / user_input / product_response / qa_response / error_response 等事件）'),
        ('打包与版本管理', 'zip 打包（agents.zip）+ Git 版本管理'),
        ('本文档生成', 'python-docx'),
    ]:
        para = doc.add_paragraph()
        r1 = para.add_run('· ' + k + '：')
        set_font(r1, bold=True)
        r2 = para.add_run(v)
        set_font(r2)

    # ========== 二、实现原理 ==========
    heading(doc, '二、实现原理', 1)

    heading(doc, '2.1 实验设计', 2)
    p(doc, '采用「商品 × 组别」结构：6 个商品（A4白纸、一次性纸杯、金属中性笔、透明胶带大卷、垃圾袋、软毛牙刷）'
           '× 2 个组别（协作规范诉求组 / 非协作规范诉求组）= 12 个独立 Agent。每个 Agent 内置该商品的'
           '非环保款（A）与环保款（B）两类商品信息（外观描述 + 价格）。协作组与非协作组仅在干预文案的'
           '规范诉求关键词上区分，从而实现对"协作规范诉求"这一自变量的操纵。')

    heading(doc, '2.2 交互流程（三轮分支逻辑）', 2)
    p(doc, '交互流程按三轮推进，输入框灰字随轮次切换，每轮只有输入正确指令才推进到下一轮：')
    for k, v in [
        ('第一轮 · 待输入商品', '灰字「请输入产品名称」。被试输入本品类普通商品（差一两个字、意思一致也可，如「中性笔」）'
                       '后，Agent 输出核心操纵文案（协作组以「加入我们，让我们一起为环保做出贡献！」开头；'
                       '非协作组以「请选择绿色消费！」开头），灰字切换为「询问本店可购买的商品」。'
                       '输入错误商品时提示「抱歉，暂不支持该商品，请输入本超市商品：A4 白纸、金属中性笔、透明胶带大卷、'
                       '垃圾袋、软毛牙刷、一次性纸杯。」并停留本轮。'),
        ('第二轮 · 待询问商品信息', '灰字「询问本店可购买的商品」。被试输入询问（如「本店有什么商品」「本店能购买什么」'
                        '「本店卖什么」「有哪些商品」等，见询问词库）后，Agent 输出 A（非环保产品）/ B（环保产品）'
                        '的外观与价格信息，灰字切换为「您现在可以询问两种商品的具体信息」。未询问商品时提示并停留本轮。'),
        ('第三轮 · 自由问答', '灰字「您现在可以询问两种商品的具体信息」。此后进入自由问答：'
                      '① 追问检测（优点/缺点/用途/价格/材质/环保意义等）→ 从 A/B 知识库回答并自然收尾；'
                      '② 环保款检测 → 提示改输普通版本；③ 询问商品 → 重新展示外观价格；'
                      '④ 普通商品 → 重新展示干预文案；⑤ 兜底报错。'),
    ]:
        para = doc.add_paragraph()
        r1 = para.add_run(k)
        set_font(r1, bold=True)
        r2 = para.add_run(v)
        set_font(r2)

    heading(doc, '2.3 关键词匹配机制', 2)
    p(doc, '采用「别名包含匹配 + 关键词映射」两层机制：'
           '① 商品识别——将输入与普通款/环保款别名列表做不区分大小写的子串匹配（环保款优先于普通款，'
           '避免「竹牙刷」被普通款别名「牙刷」误命中）；'
           '② 追问识别——将输入与追问类型关键词表逐项匹配，确定回答类型（优点/价格/对比等）；'
           '③ 目标识别——通过 A/B 指代标记（如"普通款""环保款""B的""选A"）判断被试询问的是 A、B 还是两者。')

    heading(doc, '2.4 组别操纵（核心操纵句自然融入）', 2)
    p(doc, '首次输入商品时输出完整核心操纵句：协作组以"加入我们，让我们一起为环保做出贡献！"开头；'
           '非协作组以"请选择绿色消费！"开头。在后续追问回答中，核心操纵元素（协作组：加入我们/一起/共同/我们；'
           '非协作组：请选择/您/个人/绿色消费）以自然语句收尾的方式融入，避免生硬重复整句，'
           '从而在多次交互中持续、自然地进行规范诉求操纵。')

    heading(doc, '2.5 见数兼容方案', 2)
    p(doc, '见数平台对问卷中嵌入的 HTML 有一定限制，本项目提供三种形态：'
           '① agents/ 标准版（含 <script>，供本地直接打开测试）；'
           '② agents_iframe/ 将内层 HTML 整体 base64 编码后嵌入 iframe，隐藏 script/style 标签；'
           '③ agents_noscript/ 将 JS 编码后经 <body onload> 执行，彻底移除 <script> 标签。'
           '三种形态的交互逻辑完全一致。')

    # ========== 三、词库 ==========
    heading(doc, '三、词库', 1)

    heading(doc, '3.1 商品词库（非环保款 A / 环保款 B，含别名）', 2)
    for cat in GA.CATEGORIES:
        p(doc, '【%s】普通款：%s（%s元）；环保款：%s（%s元）' % (
            cat['category'], cat['normal_name'], cat['normal_price'],
            cat['eco_name'], cat['eco_price']), bold=True)
        p(doc, '普通款别名：' + '、'.join(cat['normal_aliases']))
        p(doc, '环保款别名：' + '、'.join(cat['eco_aliases']))
        p(doc, '普通款外观：' + cat['normal_appearance'])
        p(doc, '环保款外观：' + cat['eco_appearance'])

    heading(doc, '3.2 组别核心操纵句与关键词', 2)
    for k, v in [
        ('协作组', '核心操纵句「加入我们，让我们一起为环保做出贡献！」；关键词：加入我们 / 一起 / 共同 / 我们'),
        ('非协作组', '核心操纵句「请选择绿色消费！」；关键词：请选择 / 您 / 个人 / 绿色消费'),
    ]:
        para = doc.add_paragraph()
        r1 = para.add_run('· ' + k + '：')
        set_font(r1, bold=True)
        r2 = para.add_run(v)
        set_font(r2)

    heading(doc, '3.3 追问类型关键词表', 2)
    qt_keys = {
        '推荐': ['推荐', '建议', '买哪个', '选哪个', '应该买', '值得买', '买什么', '怎么选'],
        '对比': ['对比', '区别', '比较', '相比', 'vs', '哪个好', '有什么不同', '差别', '不一样', '哪个更好', '不同'],
        '价格': ['价格', '多少钱', '贵', '便宜', '成本', '花费', '划算', '价位'],
        '材质': ['材质', '材料', '成分', '什么做的', '原料'],
        '规格': ['规格', '尺寸', '容量', '多大', '多少毫升', '多少张', '多少只', '型号'],
        '效果': ['效果', '好不好用', '好用吗', '管用', '好用'],
        '性价比': ['性价比', '值不值', '值吗', '值这个价', '划得来'],
        '口碑': ['口碑', '评价', '销量', '受欢迎', '卖得好', '人气', '好评'],
        '环保意义': ['环保', '为什么环保', '环保在哪', '环保吗', '绿色', '对环境', '环境友好', '环保性'],
        '降解': ['降解', '分解', '多久', '降解时间', '分解时间', '能分解', '可降解'],
        '购买渠道': ['哪里买', '购买渠道', '怎么买', '去哪买', '在哪买', '哪里卖', '渠道'],
        '适用人群': ['适合谁', '适用人群', '什么人', '谁用', '人群', '适合什么人', '小孩', '儿童'],
        '注意事项': ['注意', '注意事项', '注意什么', '注意点', '使用注意', '提醒', '储存', '保存', '存放', '保质'],
        '优点': ['优点', '优势', '特色', '亮点', '哪里好', '好在', '好不好'],
        '好处': ['好处', '有什么用', '有什么好', '作用', '帮助'],
        '缺点': ['缺点', '不足', '劣势', '缺陷', '坏处', '不好', '问题'],
        '用途': ['用途', '怎么用', '使用场景', '能做什么', '适用', '适合', '场景', '干什么用'],
        '安全': ['安全', '有毒', '无害', '健康', '放心', '标准', '检测', '危害'],
        '耐用': ['耐用', '质量', '寿命', '持久', '容易坏', '结实', '能用多久', '能用多长时间'],
    }
    for k, v in qt_keys.items():
        para = doc.add_paragraph()
        r1 = para.add_run('· ' + k + '：')
        set_font(r1, bold=True)
        r2 = para.add_run('、'.join(v))
        set_font(r2)

    heading(doc, '3.4 环保概念科普词库', 2)
    for k, v in GA.ECO_CONCEPTS.items():
        para = doc.add_paragraph()
        r1 = para.add_run('· ' + k + '：')
        set_font(r1, bold=True)
        r2 = para.add_run(v)
        set_font(r2)

    heading(doc, '3.5 A/B 知识库（每品类 17 项 + 对比 + 推荐）', 2)
    for cat in GA.CATEGORIES:
        extra = GA.EXTRA_KB[cat['category']]
        p(doc, '【%s】' % cat['category'], bold=True, size=11)
        for item in ['优点', '好处', '缺点', '用途', '价格', '安全', '耐用', '材质', '规格', '效果', '性价比', '口碑', '环保意义', '降解', '购买渠道', '适用人群', '注意事项']:
            va = cat['normal_kb'][item] if item in cat['normal_kb'] else extra['normal'][item]
            vb = cat['eco_kb'][item] if item in cat['eco_kb'] else extra['eco'][item]
            p(doc, 'A（%s）%s：%s' % (cat['normal_name'], item, va))
            p(doc, 'B（%s）%s：%s' % (cat['eco_name'], item, vb))
        p(doc, '对比：' + cat['compare'])
        p(doc, '推荐：' + cat['recommend'])

    heading(doc, '3.6 组别语气收尾词库（自然融入）', 2)
    for gname, gmap in [('协作组', CLOSING['collaboration']), ('非协作组', CLOSING['non_collaboration'])]:
        p(doc, '【%s】' % gname, bold=True)
        for k in ['优点', '好处', '缺点', '用途', '价格', '安全', '耐用', '材质', '规格', '效果', '性价比', '口碑', '环保意义', '降解', '购买渠道', '适用人群', '注意事项', '对比', '推荐', 'eco']:
            p(doc, '· %s：%s' % (k, gmap[k]))

    # ========== 四、对应回答 ==========
    heading(doc, '四、对应回答', 1)

    heading(doc, '4.1 固定话术', 2)
    p(doc, '欢迎语：顾客您好！欢迎光临小林超市，我是本店的 AI 智能助手小林，请输入您的商品信息。')
    p(doc, '环保款提示：本次请输入普通版本商品，请重新输入对应普通商品名称。')
    p(doc, '报错（按品类）：抱歉，暂不支持该商品，请输入与X有关的商品。（X 为该品类量词，如"笔""牙刷"）')
    p(doc, '输入框灰字：初始「请输入产品名称…」；输入正确商品后变为「您现在可以询问两款产品的具体信息」。')
    p(doc, '词库未覆盖的追问兜底：关于这个问题我暂时没有更多信息。您可以向我询问这两款X的：优点、缺点、好处、用途、价格、材质、规格、效果、性价比、口碑、环保意义、降解情况、购买渠道、适用人群、注意事项等。')
    p(doc, '询问「能问什么」（帮助）：当被试问"我能问什么问题""可以问什么"等，Agent 会列出可询问的具体信息清单（优点/好处/缺点、用途/价格/材质/规格/效果、性价比/口碑/安全性/耐用性、环保意义/降解/购买渠道/适用人群/注意事项、对比/推荐，以及环保知识示例）。')

    heading(doc, '4.2 第一轮回复（输入本品类普通款 → 核心操纵文案）', 2)
    p(doc, '第一轮输入普通商品后，Agent 输出核心操纵文案（干预文案）。12 条文案逐字对照《实验参考文本》：')
    for group_type, group_label in [('collaboration', '协作组'), ('non_collaboration', '非协作组')]:
        copy_dict = GA.COLLABORATION_COPY if group_type == 'collaboration' else GA.NON_COLLABORATION_COPY
        for cat in GA.CATEGORIES:
            p(doc, '【%s · %s】%s' % (cat['category'], group_label, copy_dict[cat['copy_key']]), size=9.5)

    heading(doc, '4.3 第二轮回复（询问商品 → A/B 外观与价格）', 2)
    p(doc, '第二轮询问商品后，Agent 输出「本店有两种X售卖：」+ A（非环保产品）名称/外观/价格 + B（环保产品）名称/外观/价格。')
    for cat in GA.CATEGORIES:
        p(doc, '【%s】%s' % (cat['category'], GA.build_product_info(cat)), size=9.5)

    heading(doc, '4.4 追问回答（第三轮，示例：优点 / 价格 / 对比 / 推荐）', 2)
    p(doc, '追问回答 = A/B 知识库内容 + 组别语气收尾。下面以「笔类」为例给出协作组与非协作组的组装结果：')
    for group_type, group_label, gkey in [('collaboration', '协作组', 'collaboration'), ('non_collaboration', '非协作组', 'non_collaboration')]:
        cat = GA.CATEGORIES[0]  # 笔类
        cl = CLOSING[gkey]
        p(doc, '【%s · 笔类】' % group_label, bold=True)
        p(doc, '问「优点」：A（%s）的优点：%s%s' % (cat['normal_name'], cat['normal_kb']['优点'], cl['优点']))
        p(doc, '问「价格」：A（%s）的价格：%s B（%s）的价格：%s%s' % (
            cat['normal_name'], cat['normal_kb']['价格'], cat['eco_name'], cat['eco_kb']['价格'], cl['价格']))
        p(doc, '问「对比」：%s%s' % (cat['compare'], cl['对比']))
        p(doc, '问「推荐」：%s%s' % (cat['recommend'], cl['推荐']))

    p(doc, '（其余品类按同一模式组装，A/B 知识与收尾语见第三节词库。）', size=9.5, color=(0x66, 0x66, 0x66))

    doc.save(OUT)
    return OUT


if __name__ == '__main__':
    out = build_doc()
    print('文档已生成：%s' % out)
    print('大小：%d 字节' % os.path.getsize(out))
